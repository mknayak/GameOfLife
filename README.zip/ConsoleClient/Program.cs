﻿using manas.git.gol;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            var game = GameOfLife.Initialize(4, 7);
            game.StartGame();
            Console.WriteLine("SEED");
            DrawGOL(game.cellGrid, game);
            for (int i = 0; i < 4; i++)
            {
                var cells = game.MoveToNectGeneration();
                Console.WriteLine("Generation {0}", i);
                DrawGOL(cells, game);
            }
        }

        private static void DrawGOL(IEnumerable<IEnumerable<Cell>> cells,GameOfLife game)
        {
            foreach (var cellRow in cells)
            {
                foreach (var cell in cellRow)
                {
                    PrintCell(cell);
                }
                Console.WriteLine();
            }
        }

        static void PrintCell(Cell cell)
        {
            if (cell.State.Equals(CellState.Alive))
                Console.ForegroundColor = ConsoleColor.Green;
            else
                Console.ForegroundColor = ConsoleColor.Red;

            Console.Write("{0} ", "O");

            Console.ResetColor();
        }
    }
}
