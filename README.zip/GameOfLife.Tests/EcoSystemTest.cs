﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace manas.git.gol.tests
{
    [TestClass]
    public class EcoSystemTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
