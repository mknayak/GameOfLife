﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace manas.git.gol.tests
{
    [TestClass]
    public class GameOfLifeTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
