﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using manas.git.gol.rule;
namespace manas.git.gol
{
    public class Cell
    {
        public int cellId { get; set; }
        public Position position { get; set; }
        public IEnumerable<Cell> Neighbours { get; set; }
        public CellState State { get; set; }
        public CellState NextGenerationState { get; set; }

        public void MoveToNextGeneration()
        {
            this.State = this.NextGenerationState;
            this.NextGenerationState = CellState.None;
        }

        public void FindNextGenerationState(EcoSystem system)
        {
            SetNeighbours(system);

            this.EvaluateNextGenerationState();
        }

        private void SetNeighbours(EcoSystem system)
        {
            List<Cell> neighbours = new List<Cell>();
            AddTopCell(system, neighbours);
            AddBottomCell(system, neighbours);
            AddRightCell(system, neighbours);
            AddLeftCell(system, neighbours);
            AddTopRightCell(system, neighbours);
            AddTopLeftCell(system, neighbours);
            AddBottomRightCell(system, neighbours);
            AddBottomLeftCell(system, neighbours);
            this.Neighbours = neighbours;
        }

        private void AddTopCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(1)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - system.Columns));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddBottomCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(system.Rows)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId + system.Columns));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddRightCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.column.Equals(system.Columns)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId +1));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddLeftCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.column.Equals(1)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - 1));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddTopRightCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(1) ||
                this.position.column.Equals(system.Columns)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - system.Columns+1));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddTopLeftCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(1) ||
                this.position.column.Equals(1)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - system.Columns));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddBottomRightCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(system.Rows) ||
                this.position.column.Equals(system.Columns)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - system.Columns));
            if (topCell != null) neighbours.Add(topCell);
        }
        private void AddBottomLeftCell(EcoSystem system, List<Cell> neighbours)
        {
            if (this.position.row.Equals(system.Rows) ||
                this.position.column.Equals(1)) return;

            Cell topCell = system.cells.FirstOrDefault(c => c.cellId.Equals(this.cellId - system.Columns));
            if (topCell != null) neighbours.Add(topCell);
        }
    }
}
