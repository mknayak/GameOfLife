﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace manas.git.gol
{
    public class Position
    {
        public int row { get; set; }
        public int column { get; set; }
    }
}
