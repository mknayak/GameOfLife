﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace manas.git.gol
{
    public class GameOfLife
    {
        public EcoSystem System { get; set; }
        public IEnumerable<IEnumerable<Cell>> cellGrid { get; set; }

        public static GameOfLife Initialize(int rows, int columns)
        {
            List<List<Cell>> cells = new List<List<Cell>>();
            for (int i = 1; i <= rows; i++)
            {
                var cellRow = new List<Cell>();
                for (int j = 1; j <= columns; j++)
                {
                    cellRow.Add(new Cell
                    {
                        cellId = columns * (i - 1) + j,
                        position = new Position { row = i, column = j }
                    });
                }
                cells.Add(cellRow);
            }

            GameOfLife gol = new GameOfLife();
            gol.cellGrid = cells;
            gol.System = new EcoSystem() { cells = cells.SelectMany(c=>c), Columns = columns, Rows = rows };

            return gol;
        }

        public void StartGame()
        {
            Random rnd = new Random();
            List<int> aliveList = new List<int>();
            aliveList.Add(5);
            aliveList.Add(6);
            aliveList.Add(12);
            aliveList.Add(13);
            aliveList.Add(15);
            aliveList.Add(25);
            aliveList.Add(26);
            aliveList.Add(27);

            StartGameWithSeed(aliveList);
        }

        public void StartGameWithSeed(IEnumerable<int> aliveCells)
        {
            foreach (var cellId in aliveCells)
            {
                var selectedCell = this.System.cells.FirstOrDefault(c => c.cellId.Equals(cellId));
                if (selectedCell != null)
                {
                    selectedCell.State = CellState.Alive;
                }
            }
        }

        public IEnumerable<IEnumerable<Cell>> MoveToNectGeneration()
        {
            this.System.FindNextGenerationState();
            this.System.MoveToNextGeneration();
            return this.cellGrid;
        }
    }
}
