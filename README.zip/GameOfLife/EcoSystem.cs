﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace manas.git.gol
{
    public class EcoSystem
    {
        public EcoSystem()
        {

        }
        /// <summary>
        /// Gets or sets the cells.
        /// </summary>
        /// <value>
        /// The cells.
        /// </value>
        public IEnumerable<Cell> cells { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }
        public void FindNextGenerationState()
        {
            foreach (var cell in cells)
            {
                cell.FindNextGenerationState(this);
            }
        }
        public void MoveToNextGeneration()
        {
            foreach (var cell in cells)
            {
                cell.MoveToNextGeneration();
            }
        }
    }
}
