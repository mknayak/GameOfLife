GameOfLife
==========

Simple solution for "Game Of Life" problem.

Define EcoSystem with orthogonal grids.
Set random seed values.
StartGame.